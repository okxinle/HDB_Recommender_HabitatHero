// TODO: Define persistence access methods for HDB blocks and spatial queries.
