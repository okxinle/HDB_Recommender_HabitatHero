// TODO: Model HDB block attributes, geospatial coordinates, and livability features.
