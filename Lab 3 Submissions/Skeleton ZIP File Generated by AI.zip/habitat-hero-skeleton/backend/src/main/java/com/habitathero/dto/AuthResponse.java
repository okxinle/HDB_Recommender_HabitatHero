// TODO: Define the response payload for authentication workflows.
