// TODO: Define persistence access methods for resale transaction data.
