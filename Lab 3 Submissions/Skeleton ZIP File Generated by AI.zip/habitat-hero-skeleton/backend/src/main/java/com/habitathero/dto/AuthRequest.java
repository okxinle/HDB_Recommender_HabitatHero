// TODO: Define the request payload for login and registration workflows.
