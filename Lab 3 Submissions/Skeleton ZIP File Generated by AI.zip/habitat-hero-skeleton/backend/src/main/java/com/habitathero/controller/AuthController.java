// TODO: Expose login, registration, and logout endpoints.
