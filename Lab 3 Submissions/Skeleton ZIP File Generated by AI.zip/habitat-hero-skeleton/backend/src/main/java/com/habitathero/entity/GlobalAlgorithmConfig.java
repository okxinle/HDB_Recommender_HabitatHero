// TODO: Model tunable parameters used by recommendation scoring.
