// TODO: Model resale transaction records imported from external data sources.
