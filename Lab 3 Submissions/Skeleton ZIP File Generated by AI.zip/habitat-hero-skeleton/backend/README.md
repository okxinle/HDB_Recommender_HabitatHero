<!-- TODO: Describe backend setup, environment variables, database connection, and run commands. -->
