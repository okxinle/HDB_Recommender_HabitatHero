# TODO: Fetch and normalize transport route and stop data.
