# TODO: Enrich HDB blocks with derived geospatial and livability attributes.
