<!-- TODO: Describe frontend setup, scripts, environment variables, and build process. -->
