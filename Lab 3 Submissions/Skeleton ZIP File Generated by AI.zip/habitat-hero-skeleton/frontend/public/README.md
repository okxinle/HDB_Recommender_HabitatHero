<!-- TODO: Store static assets such as icons, logos, and public images here. -->
