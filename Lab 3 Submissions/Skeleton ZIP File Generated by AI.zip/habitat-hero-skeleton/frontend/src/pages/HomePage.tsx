// TODO: Build the landing page and entry point to the lifestyle quiz.
