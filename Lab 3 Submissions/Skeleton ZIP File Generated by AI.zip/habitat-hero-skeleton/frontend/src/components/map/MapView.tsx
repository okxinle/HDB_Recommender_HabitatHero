// TODO: Render HDB blocks and transport overlays on an interactive map.
