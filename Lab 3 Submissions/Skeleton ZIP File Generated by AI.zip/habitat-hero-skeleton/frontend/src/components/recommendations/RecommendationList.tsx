// TODO: Render recommendation cards, scores, and shortlist actions.
