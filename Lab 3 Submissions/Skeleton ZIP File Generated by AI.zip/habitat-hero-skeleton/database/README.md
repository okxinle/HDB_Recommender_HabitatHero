<!-- TODO: Explain schema setup, PostGIS enablement, and migration order. -->
