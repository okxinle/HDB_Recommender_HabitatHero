<!-- TODO: Document deployment options, environment setup, and infrastructure decisions. -->
