<!-- TODO: Describe REST endpoints, request/response DTOs, and authentication flow. -->
