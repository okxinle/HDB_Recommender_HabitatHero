<!-- TODO: Document system architecture, BCE mapping, and major subsystems. -->
