CREATE EXTENSION IF NOT EXISTS postgis;

ALTER TABLE hdb_blocks
    ADD COLUMN IF NOT EXISTS geom geometry(Point, 4326);

CREATE INDEX IF NOT EXISTS idx_hdb_blocks_geom ON hdb_blocks USING GIST (geom);
