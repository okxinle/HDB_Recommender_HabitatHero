CREATE TABLE IF NOT EXISTS user_accounts (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(180) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    failed_login_attempts INTEGER NOT NULL DEFAULT 0,
    lock_until TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_profiles (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE REFERENCES user_accounts(id) ON DELETE CASCADE,
    budget_min NUMERIC(12, 2),
    budget_max NUMERIC(12, 2),
    preferred_regions TEXT,
    preferred_towns TEXT,
    preferred_flat_type VARCHAR(60),
    min_lease_years INTEGER,
    solar_mode VARCHAR(20),
    solar_weight NUMERIC(5, 2),
    acoustic_mode VARCHAR(20),
    acoustic_weight NUMERIC(5, 2),
    convenience_mode VARCHAR(20),
    convenience_weight NUMERIC(5, 2),
    selected_amenities TEXT,
    parents_postal_code VARCHAR(6),
    commuter_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    commuter_destination_a VARCHAR(6),
    commuter_destination_b VARCHAR(6),
    commute_fairness_weight NUMERIC(5, 2),
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hdb_blocks (
    id BIGSERIAL PRIMARY KEY,
    block_label VARCHAR(50),
    postal_code VARCHAR(12) UNIQUE,
    town VARCHAR(80),
    region VARCHAR(40),
    flat_type VARCHAR(40),
    estimated_price NUMERIC(12, 2),
    remaining_lease_years INTEGER,
    floor_area_sqm NUMERIC(10, 2),
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    west_sun_status BOOLEAN,
    west_exposure_pct DOUBLE PRECISION,
    noise_risk_level VARCHAR(20),
    noise_level_db DOUBLE PRECISION,
    distance_to_transport_meters DOUBLE PRECISION,
    future_risk_flag BOOLEAN,
    future_development_count INTEGER,
    distance_to_parents_km DOUBLE PRECISION,
    nearby_school_count INTEGER,
    nearby_hawker_count INTEGER,
    nearby_supermarket_count INTEGER,
    nearby_park_count INTEGER,
    nearby_hospital_count INTEGER,
    nearby_playground_count INTEGER
);

CREATE TABLE IF NOT EXISTS resale_transactions (
    id BIGSERIAL PRIMARY KEY,
    block_id BIGINT,
    town VARCHAR(80),
    resale_price NUMERIC(12, 2),
    floor_area_sqm NUMERIC(10, 2),
    lease_commencement_date DATE,
    transaction_month VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGSERIAL PRIMARY KEY,
    admin_email VARCHAR(180),
    action_name VARCHAR(120),
    endpoint_url VARCHAR(255),
    ip_address VARCHAR(64),
    details TEXT,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS global_algorithm_configs (
    config_key VARCHAR(100) PRIMARY KEY,
    config_value DOUBLE PRECISION NOT NULL,
    description TEXT
);
