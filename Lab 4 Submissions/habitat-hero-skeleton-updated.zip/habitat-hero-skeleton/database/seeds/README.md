# Seed Data

Add optional CSV or SQL seed data here for demo environments, for example:
- sample HDB blocks
- sample resale transactions
- sample global config weights
