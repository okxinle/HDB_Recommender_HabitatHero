# Database Setup

## Migration order
1. Run `schema/001_init.sql`
2. Run `schema/002_postgis.sql` if PostGIS is available

## Main tables
- `user_accounts`
- `user_profiles`
- `hdb_blocks`
- `resale_transactions`
- `audit_logs`
- `global_algorithm_configs`
