# API Contract Skeleton

## Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`

## Profile
- `GET /api/profile`
- `PUT /api/profile`

## Recommendations
- `POST /api/hdb/recommend`
- `GET /api/hdb/{postalCode}/details`

## Admin
- `POST /api/admin/trigger-sync`
- `POST /api/admin/init-hdb-building`
- `POST /api/admin/backfill-coordinates`
- `POST /api/admin/init-land-use`
- `PATCH /api/admin/weights`
- `GET /api/admin/logs`
