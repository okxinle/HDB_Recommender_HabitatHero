# HabitatHero Architecture Skeleton

## Layers
1. Presentation Layer
   - React SPA pages and components
2. Boundary Layer
   - Spring REST controllers
3. Control Layer
   - AuthService, ProfileService, RecommendationEngine, GeospatialService, DataSyncService
4. Persistent Data Layer
   - PostgreSQL repositories and schema scripts

## Recommendation flow
1. User submits hybrid profile
2. Recommendation controller calls RecommendationEngine
3. Engine validates structural constraints
4. Engine fetches candidate HDB blocks
5. Engine computes solar, acoustic, convenience, and optional commute score
6. Engine filters strict failures
7. Engine ranks by global match index
