# HabitatHero Skeleton

This updated skeleton aligns the generated project structure to the HabitatHero SRS.

## Included
- Spring Boot backend skeleton with:
  - authentication endpoints
  - profile endpoints
  - recommendation endpoint
  - admin sync/config/log endpoints
- React frontend skeleton with:
  - landing page
  - lifestyle quiz/profile form
  - recommendations page
  - admin panel placeholder
- PostgreSQL schema and PostGIS extension script
- Architecture and API documentation stubs updated from the SRS

## Run locally
### Backend
```bash
cd backend
mvn spring-boot:run
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Notes
- Security uses a lightweight placeholder bearer token service for skeleton purposes.
- Recommendation scoring is intentionally simplified but follows the SRS flow:
  hard filter -> optional commute analysis -> livability scoring -> strict filtering -> global match index.
