# Infrastructure Notes

This folder contains lightweight local infrastructure assets for the skeleton project.

- `docker-compose.yml`: local PostgreSQL container
- `render.yaml`: placeholder managed deployment file
