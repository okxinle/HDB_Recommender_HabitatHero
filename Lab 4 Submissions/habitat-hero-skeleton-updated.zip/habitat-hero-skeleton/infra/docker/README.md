# Local Docker Usage

Use `docker-compose.yml` to start a local PostgreSQL instance for the backend skeleton.

```bash
docker compose up -d
```
