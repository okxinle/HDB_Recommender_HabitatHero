import { useState } from "react";
import { fetchAdminLogs, triggerAdminAction } from "../../services/api";

function AdminPanel() {
  const [output, setOutput] = useState<string>("");

  async function run(path: string) {
    try {
      const payload = await triggerAdminAction(path);
      setOutput(JSON.stringify(payload, null, 2));
    } catch (error) {
      setOutput(error instanceof Error ? error.message : "Admin action failed.");
    }
  }

  async function loadLogs() {
    try {
      const payload = await fetchAdminLogs();
      setOutput(JSON.stringify(payload, null, 2));
    } catch (error) {
      setOutput(error instanceof Error ? error.message : "Unable to load logs.");
    }
  }

  return (
    <div className="card stack">
      <h3>Admin Panel Skeleton</h3>
      <p>Headless admin operations from the SRS are exposed as backend REST actions.</p>
      <div className="row wrap">
        <button className="button secondary" type="button" onClick={() => run("/api/admin/trigger-sync")}>
          Trigger Sync
        </button>
        <button className="button secondary" type="button" onClick={() => run("/api/admin/init-hdb-building")}>
          Init HDB Building
        </button>
        <button className="button secondary" type="button" onClick={() => run("/api/admin/backfill-coordinates")}>
          Backfill Coordinates
        </button>
        <button className="button secondary" type="button" onClick={() => run("/api/admin/init-land-use")}>
          Init Land Use
        </button>
        <button className="button secondary" type="button" onClick={loadLogs}>
          View Logs
        </button>
      </div>
      <pre>{output || "Admin responses will appear here."}</pre>
    </div>
  );
}

export default AdminPanel;
