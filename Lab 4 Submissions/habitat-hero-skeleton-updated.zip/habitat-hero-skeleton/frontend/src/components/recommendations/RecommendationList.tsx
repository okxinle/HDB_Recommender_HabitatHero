import type { RecommendationResponse } from "../../services/api";

type Props = {
  response: RecommendationResponse;
};

function RecommendationList({ response }: Props) {
  return (
    <div className="card stack">
      <h3>Ranked Recommendations</h3>
      {response.results.length === 0 ? (
        <p>No recommendations loaded yet. Complete the profile form to generate a shortlist.</p>
      ) : (
        <ul className="list">
          {response.results.map((block) => (
            <li key={block.blockId} className="list-item">
              <div>
                <strong>{block.blockLabel ?? block.postalCode}</strong>
                <div>{block.town}, {block.region}</div>
                <div>{block.flatType}</div>
              </div>
              <div className="metrics">
                <span>{block.globalMatchIndex?.toFixed(1)}%</span>
                <span>${block.estimatedPrice?.toLocaleString()}</span>
                <span>{block.remainingLeaseYears} yrs lease</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default RecommendationList;
