import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { generateRecommendations, saveProfile, type ProfileRequest } from "../../services/api";
import AdminPanel from "../admin/AdminPanel";

const defaultProfile: ProfileRequest = {
  budgetMin: 400000,
  budgetMax: 700000,
  preferredRegions: ["East"],
  preferredTowns: ["Tampines"],
  preferredFlatType: "5 Room",
  minLeaseYears: 50,
  solarMode: "STRICT",
  solarWeight: 0.5,
  acousticMode: "WEIGHTED",
  acousticWeight: 0.5,
  convenienceMode: "STRICT",
  convenienceWeight: 0.5,
  selectedAmenities: ["SUPERMARKET", "SCHOOL", "PLAYGROUND"],
  commuterEnabled: false,
  commuteFairnessWeight: 0.5
};

function ProfileForm() {
  const [profile, setProfile] = useState<ProfileRequest>(defaultProfile);
  const [status, setStatus] = useState<string>("");
  const navigate = useNavigate();

  function patch<K extends keyof ProfileRequest>(key: K, value: ProfileRequest[K]) {
    setProfile((current) => ({ ...current, [key]: value }));
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus("Generating recommendations...");
    try {
      await saveProfile(profile).catch(() => undefined);
      const results = await generateRecommendations(profile);
      navigate("/recommendations", { state: results });
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to generate recommendations.");
    }
  }

  return (
    <div className="grid cols-2">
      <form className="card stack" onSubmit={onSubmit}>
        <h3>Step 1: Structural Constraints</h3>

        <label>
          Budget Minimum
          <input
            type="number"
            value={profile.budgetMin ?? ""}
            onChange={(e) => patch("budgetMin", Number(e.target.value))}
          />
        </label>

        <label>
          Budget Maximum
          <input
            type="number"
            value={profile.budgetMax ?? ""}
            onChange={(e) => patch("budgetMax", Number(e.target.value))}
          />
        </label>

        <label>
          Preferred Region
          <input
            value={profile.preferredRegions?.join(", ") ?? ""}
            onChange={(e) => patch("preferredRegions", e.target.value.split(",").map((value) => value.trim()).filter(Boolean))}
          />
        </label>

        <label>
          Preferred Towns
          <input
            value={profile.preferredTowns?.join(", ") ?? ""}
            onChange={(e) => patch("preferredTowns", e.target.value.split(",").map((value) => value.trim()).filter(Boolean))}
          />
        </label>

        <label>
          Preferred Flat Type
          <input
            value={profile.preferredFlatType ?? ""}
            onChange={(e) => patch("preferredFlatType", e.target.value)}
          />
        </label>

        <label>
          Minimum Lease Years
          <input
            type="number"
            value={profile.minLeaseYears ?? ""}
            onChange={(e) => patch("minLeaseYears", Number(e.target.value))}
          />
        </label>

        <h3>Step 2: Livability Factors</h3>

        <label>
          Solar Orientation Mode
          <select value={profile.solarMode} onChange={(e) => patch("solarMode", e.target.value)}>
            <option value="IGNORE">Ignore</option>
            <option value="STRICT">Strict</option>
            <option value="WEIGHTED">Weighted</option>
          </select>
        </label>

        <label>
          Acoustic Comfort Mode
          <select value={profile.acousticMode} onChange={(e) => patch("acousticMode", e.target.value)}>
            <option value="IGNORE">Ignore</option>
            <option value="STRICT">Strict</option>
            <option value="WEIGHTED">Weighted</option>
          </select>
        </label>

        <label>
          Convenience Mode
          <select value={profile.convenienceMode} onChange={(e) => patch("convenienceMode", e.target.value)}>
            <option value="IGNORE">Ignore</option>
            <option value="STRICT">Strict</option>
            <option value="WEIGHTED">Weighted</option>
          </select>
        </label>

        <label>
          Selected Amenities
          <input
            value={profile.selectedAmenities.join(", ")}
            onChange={(e) => patch("selectedAmenities", e.target.value.split(",").map((value) => value.trim()).filter(Boolean))}
          />
        </label>

        <h3>Step 3: Multi-Commuter Analysis</h3>

        <label className="inline">
          <input
            type="checkbox"
            checked={Boolean(profile.commuterEnabled)}
            onChange={(e) => patch("commuterEnabled", e.target.checked)}
          />
          Enable two-commuter analysis
        </label>

        <label>
          Commuter Destination A
          <input
            value={profile.commuterDestinationA ?? ""}
            onChange={(e) => patch("commuterDestinationA", e.target.value)}
          />
        </label>

        <label>
          Commuter Destination B
          <input
            value={profile.commuterDestinationB ?? ""}
            onChange={(e) => patch("commuterDestinationB", e.target.value)}
          />
        </label>

        <div className="row">
          <button className="button" type="submit">Find My HDB Match</button>
          {status ? <span>{status}</span> : null}
        </div>
      </form>

      <div className="stack">
        <div className="card">
          <h3>Summary</h3>
          <pre>{JSON.stringify(profile, null, 2)}</pre>
        </div>
        <AdminPanel />
      </div>
    </div>
  );
}

export default ProfileForm;
