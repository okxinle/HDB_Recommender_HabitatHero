import type { BlockMatch } from "../../services/api";

type Props = {
  blocks: BlockMatch[];
};

function MapView({ blocks }: Props) {
  return (
    <div className="card stack">
      <h3>Spatial Analysis Placeholder</h3>
      <p>
        Replace this panel with React-Leaflet or your preferred map library. The SRS expects
        block-level map overlays for nearby amenities, transport context, and future development risk.
      </p>

      <div className="map-placeholder">
        {blocks.length === 0 ? "No blocks loaded." : `${blocks.length} block(s) ready for map rendering.`}
      </div>
    </div>
  );
}

export default MapView;
