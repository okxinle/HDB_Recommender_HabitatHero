import { authJson } from "./auth";

export type ProfileRequest = {
  budgetMin?: number;
  budgetMax?: number;
  preferredRegions: string[];
  preferredTowns: string[];
  preferredFlatType?: string;
  minLeaseYears?: number;
  solarMode?: string;
  solarWeight?: number;
  acousticMode?: string;
  acousticWeight?: number;
  convenienceMode?: string;
  convenienceWeight?: number;
  selectedAmenities: string[];
  parentsPostalCode?: string;
  commuterEnabled?: boolean;
  commuterDestinationA?: string;
  commuterDestinationB?: string;
  commuteFairnessWeight?: number;
};

export type BlockMatch = {
  blockId: number;
  postalCode: string;
  blockLabel?: string;
  town: string;
  region: string;
  flatType: string;
  estimatedPrice?: number;
  remainingLeaseYears?: number;
  floorAreaSqm?: number;
  globalMatchIndex?: number;
  commuteScore?: number;
  fairnessIndex?: number;
  totalCommuteBurden?: number;
  westSunStatus?: boolean;
  noiseRiskLevel?: string;
  futureRiskFlag?: boolean;
};

export type RecommendationResponse = {
  status: string;
  warning?: string;
  candidateCount: number;
  results: BlockMatch[];
};

export async function saveProfile(profile: ProfileRequest) {
  return authJson("/api/profile", {
    method: "PUT",
    body: JSON.stringify(profile)
  });
}

export async function loadProfile() {
  return authJson<ProfileRequest>("/api/profile");
}

export async function generateRecommendations(profile: ProfileRequest) {
  return authJson<RecommendationResponse>("/api/hdb/recommend", {
    method: "POST",
    body: JSON.stringify({ profile, limit: 12 })
  });
}

export async function fetchAdminLogs() {
  return authJson("/api/admin/logs");
}

export async function triggerAdminAction(path: string) {
  return authJson(path, { method: "POST" });
}
