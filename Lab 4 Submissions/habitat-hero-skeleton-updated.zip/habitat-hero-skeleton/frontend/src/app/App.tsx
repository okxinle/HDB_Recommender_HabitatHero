import { NavLink, Route, Routes } from "react-router-dom";
import HomePage from "../pages/HomePage";
import ProfilePage from "../pages/ProfilePage";
import RecommendationsPage from "../pages/RecommendationsPage";

function App() {
  return (
    <div className="shell">
      <header className="topbar">
        <div>
          <h1>HabitatHero</h1>
          <p>A lifestyle-first HDB recommender.</p>
        </div>
        <nav>
          <NavLink to="/">Home</NavLink>
          <NavLink to="/profile">Lifestyle Quiz</NavLink>
          <NavLink to="/recommendations">Results</NavLink>
        </nav>
      </header>

      <main className="page">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/recommendations" element={<RecommendationsPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
