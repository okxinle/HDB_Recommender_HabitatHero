import { Link } from "react-router-dom";

function HomePage() {
  return (
    <section className="stack">
      <div className="card hero">
        <h2>Find HDB matches based on comfort, commute, and affordability.</h2>
        <p>
          HabitatHero combines structural constraints, livability factors, and optional
          multi-commuter analysis into one ranked shortlist of HDB blocks.
        </p>
        <div className="row">
          <Link className="button" to="/profile">
            Start Lifestyle Quiz
          </Link>
          <Link className="button secondary" to="/recommendations">
            View Sample Results
          </Link>
        </div>
      </div>

      <div className="grid cols-3">
        <article className="card">
          <h3>Structural Constraints</h3>
          <p>Budget, towns, flat type, and minimum lease remaining act as hard filters.</p>
        </article>
        <article className="card">
          <h3>Livability Factors</h3>
          <p>Solar orientation, acoustic comfort, and convenience can be ignored, strict, or weighted.</p>
        </article>
        <article className="card">
          <h3>Block-Level Insights</h3>
          <p>Results include comfort indicators, future risk flags, and comparative affordability context.</p>
        </article>
      </div>
    </section>
  );
}

export default HomePage;
