import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import type { RecommendationResponse } from "../services/api";
import RecommendationList from "../components/recommendations/RecommendationList";
import MapView from "../components/map/MapView";

function RecommendationsPage() {
  const location = useLocation();
  const response = useMemo(() => {
    return (location.state as RecommendationResponse | undefined) ?? {
      status: "empty",
      candidateCount: 0,
      results: []
    };
  }, [location.state]);

  return (
    <section className="stack">
      <div className="card">
        <h2>Results Dashboard</h2>
        <p>
          Ranked HDB blocks are shown below. The final Global Match Index reflects
          structural compatibility, livability fit, and optional commute fairness.
        </p>
        {response.warning ? <p className="warning">{response.warning}</p> : null}
      </div>

      <div className="grid cols-2">
        <RecommendationList response={response} />
        <MapView blocks={response.results} />
      </div>
    </section>
  );
}

export default RecommendationsPage;
