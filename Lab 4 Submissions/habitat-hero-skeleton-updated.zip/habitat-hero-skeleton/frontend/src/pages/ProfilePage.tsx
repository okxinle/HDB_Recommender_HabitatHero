import ProfileForm from "../components/profile/ProfileForm";

function ProfilePage() {
  return (
    <section className="stack">
      <div className="card">
        <h2>Hybrid User Profiling</h2>
        <p>
          Capture hard filters, livability preferences, and optional two-commuter inputs
          before generating recommendations.
        </p>
      </div>
      <ProfileForm />
    </section>
  );
}

export default ProfilePage;
