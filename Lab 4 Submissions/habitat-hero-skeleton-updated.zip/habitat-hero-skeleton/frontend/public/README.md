# Public Assets

Place static images, logos, and icon files here if your frontend build needs them.
