# Frontend Skeleton

The frontend reflects the user-facing requirements in the SRS:
- Home page
- Lifestyle quiz / profile page
- Recommendations dashboard
- Admin panel placeholder

## Run
```bash
npm install
npm run dev
```

## Current scope
The UI is intentionally lightweight. It provides the required screens and wiring but leaves room for your final styling, map integration, and explanation panels.
