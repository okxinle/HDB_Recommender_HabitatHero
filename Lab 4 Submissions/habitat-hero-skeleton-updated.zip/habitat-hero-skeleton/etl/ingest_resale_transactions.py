from pathlib import Path
import csv
import json

def ingest_resale_transactions(source_path: str, output_path: str) -> None:
    """
    Skeleton ETL task for the data.gov.sg resale dataset.

    Expected production responsibilities:
    - fetch raw API pages
    - normalize month, town, floor area, price, and lease fields
    - export a clean CSV or load directly into PostgreSQL
    """
    source = Path(source_path)
    rows = json.loads(source.read_text()) if source.suffix == ".json" else []

    with Path(output_path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["town", "resale_price", "floor_area_sqm", "transaction_month"])
        for row in rows:
            writer.writerow([
                row.get("town"),
                row.get("resale_price"),
                row.get("floor_area_sqm"),
                row.get("month"),
            ])

if __name__ == "__main__":
    print("Resale transaction ETL skeleton. Replace with live data.gov.sg ingestion.")
