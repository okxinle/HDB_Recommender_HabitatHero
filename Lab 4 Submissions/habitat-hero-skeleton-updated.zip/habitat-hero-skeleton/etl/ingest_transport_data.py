def ingest_transport_data() -> None:
    """
    Skeleton for transport geometry ingestion.

    Production version should:
    - download transport line geometries
    - transform CRS if needed
    - load lines/stations into PostGIS
    """
    print("Transport data ETL skeleton. Replace with live geospatial ingestion.")

if __name__ == "__main__":
    ingest_transport_data()
