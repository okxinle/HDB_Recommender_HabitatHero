# ETL Skeleton

The SRS depends on three data ingestion categories:
- HDB resale transaction history
- transport/rail geometry
- geospatial enrichment outputs

The scripts in this folder are placeholders to show where those pipelines would live.
