# Backend Skeleton

## Main SRS-aligned modules
- `AuthController`: registration, login, logout
- `ProfileController`: save and retrieve hybrid user profile
- `RecommendationController`: generate recommendations and view block details
- `AdminController`: headless admin sync and config endpoints
- `RecommendationEngine`: hard filtering, livability scoring, commute scoring, ranking
- `GeospatialService`: placeholder solar, noise, and convenience calculations

## Environment
The backend reads standard Spring datasource variables plus:
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USERNAME`
- `DB_PASSWORD`
- `APP_TOKEN_SECRET`
- `DATAGOV_API_KEY`

## Caveat
This is a development skeleton, not the full production codebase.
