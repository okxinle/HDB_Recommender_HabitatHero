package com.habitathero.dto;

import java.util.List;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class RecommendationResponse {
    String status;
    String warning;
    Integer candidateCount;
    List<BlockMatchDto> results;
}
