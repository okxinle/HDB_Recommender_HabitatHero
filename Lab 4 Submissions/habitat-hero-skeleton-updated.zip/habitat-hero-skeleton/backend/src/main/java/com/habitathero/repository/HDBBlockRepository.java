package com.habitathero.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.habitathero.entity.HDBBlock;

public interface HDBBlockRepository extends JpaRepository<HDBBlock, Long> {
    Optional<HDBBlock> findByPostalCode(String postalCode);
    List<HDBBlock> findByTownIgnoreCase(String town);
}
