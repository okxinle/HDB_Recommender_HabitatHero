package com.habitathero.dto;

import java.util.List;

import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class ProfileRequest {

    private Double budgetMin;
    private Double budgetMax;
    private List<String> preferredRegions;
    private List<String> preferredTowns;
    private String preferredFlatType;

    @Min(0)
    private Integer minLeaseYears;

    private String solarMode;
    private Double solarWeight;

    private String acousticMode;
    private Double acousticWeight;

    private String convenienceMode;
    private Double convenienceWeight;

    private List<String> selectedAmenities;
    private String parentsPostalCode;

    private Boolean commuterEnabled;
    private String commuterDestinationA;
    private String commuterDestinationB;
    private Double commuteFairnessWeight;
}
