package com.habitathero.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.habitathero.entity.UserProfile;

public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {
    Optional<UserProfile> findByUserAccountId(Long userId);
}
