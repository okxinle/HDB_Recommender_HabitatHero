package com.habitathero.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.habitathero.dto.ProfileRequest;
import com.habitathero.service.ProfileService;
import com.habitathero.service.TokenService;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    private final ProfileService profileService;

    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @GetMapping
    public ResponseEntity<?> getProfile(Authentication authentication) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(profileService.getProfile(principal.userId()));
    }

    @PutMapping
    public ResponseEntity<?> saveProfile(Authentication authentication, @RequestBody ProfileRequest request) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(profileService.saveProfile(principal.userId(), request));
    }
}
