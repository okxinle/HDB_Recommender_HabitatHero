package com.habitathero.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_profiles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private UserAccount userAccount;

    @Column(name = "budget_min")
    private Double budgetMin;

    @Column(name = "budget_max")
    private Double budgetMax;

    @Column(name = "preferred_regions")
    private String preferredRegionsCsv;

    @Column(name = "preferred_towns")
    private String preferredTownsCsv;

    @Column(name = "preferred_flat_type")
    private String preferredFlatType;

    @Column(name = "min_lease_years")
    private Integer minLeaseYears;

    @Column(name = "solar_mode")
    private String solarMode;

    @Column(name = "solar_weight")
    private Double solarWeight;

    @Column(name = "acoustic_mode")
    private String acousticMode;

    @Column(name = "acoustic_weight")
    private Double acousticWeight;

    @Column(name = "convenience_mode")
    private String convenienceMode;

    @Column(name = "convenience_weight")
    private Double convenienceWeight;

    @Column(name = "selected_amenities")
    private String selectedAmenitiesCsv;

    @Column(name = "parents_postal_code")
    private String parentsPostalCode;

    @Builder.Default
    @Column(name = "commuter_enabled", nullable = false)
    private Boolean commuterEnabled = false;

    @Column(name = "commuter_destination_a")
    private String commuterDestinationA;

    @Column(name = "commuter_destination_b")
    private String commuterDestinationB;

    @Column(name = "commute_fairness_weight")
    private Double commuteFairnessWeight;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    void onSave() {
        updatedAt = LocalDateTime.now();
        if (commuterEnabled == null) {
            commuterEnabled = false;
        }
    }
}
