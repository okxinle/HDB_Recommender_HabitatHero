package com.habitathero.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.habitathero.dto.ProfileRequest;
import com.habitathero.dto.ProfileResponse;
import com.habitathero.entity.UserAccount;
import com.habitathero.entity.UserProfile;
import com.habitathero.repository.UserAccountRepository;
import com.habitathero.repository.UserProfileRepository;

@Service
public class ProfileService {

    private final UserProfileRepository userProfileRepository;
    private final UserAccountRepository userAccountRepository;

    public ProfileService(UserProfileRepository userProfileRepository, UserAccountRepository userAccountRepository) {
        this.userProfileRepository = userProfileRepository;
        this.userAccountRepository = userAccountRepository;
    }

    public ProfileResponse getProfile(Long userId) {
        return userProfileRepository.findByUserAccountId(userId)
                .map(this::toResponse)
                .orElse(ProfileResponse.builder().userId(userId).build());
    }

    public ProfileResponse saveProfile(Long userId, ProfileRequest request) {
        UserAccount account = userAccountRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        UserProfile profile = userProfileRepository.findByUserAccountId(userId)
                .orElse(UserProfile.builder().userAccount(account).build());

        profile.setBudgetMin(request.getBudgetMin());
        profile.setBudgetMax(request.getBudgetMax());
        profile.setPreferredRegionsCsv(join(request.getPreferredRegions()));
        profile.setPreferredTownsCsv(join(request.getPreferredTowns()));
        profile.setPreferredFlatType(request.getPreferredFlatType());
        profile.setMinLeaseYears(request.getMinLeaseYears());
        profile.setSolarMode(request.getSolarMode());
        profile.setSolarWeight(request.getSolarWeight());
        profile.setAcousticMode(request.getAcousticMode());
        profile.setAcousticWeight(request.getAcousticWeight());
        profile.setConvenienceMode(request.getConvenienceMode());
        profile.setConvenienceWeight(request.getConvenienceWeight());
        profile.setSelectedAmenitiesCsv(join(request.getSelectedAmenities()));
        profile.setParentsPostalCode(request.getParentsPostalCode());
        profile.setCommuterEnabled(Boolean.TRUE.equals(request.getCommuterEnabled()));
        profile.setCommuterDestinationA(request.getCommuterDestinationA());
        profile.setCommuterDestinationB(request.getCommuterDestinationB());
        profile.setCommuteFairnessWeight(request.getCommuteFairnessWeight());

        return toResponse(userProfileRepository.save(profile));
    }

    private ProfileResponse toResponse(UserProfile profile) {
        return ProfileResponse.builder()
                .userId(profile.getUserAccount().getId())
                .budgetMin(profile.getBudgetMin())
                .budgetMax(profile.getBudgetMax())
                .preferredRegions(split(profile.getPreferredRegionsCsv()))
                .preferredTowns(split(profile.getPreferredTownsCsv()))
                .preferredFlatType(profile.getPreferredFlatType())
                .minLeaseYears(profile.getMinLeaseYears())
                .solarMode(profile.getSolarMode())
                .solarWeight(profile.getSolarWeight())
                .acousticMode(profile.getAcousticMode())
                .acousticWeight(profile.getAcousticWeight())
                .convenienceMode(profile.getConvenienceMode())
                .convenienceWeight(profile.getConvenienceWeight())
                .selectedAmenities(split(profile.getSelectedAmenitiesCsv()))
                .parentsPostalCode(profile.getParentsPostalCode())
                .commuterEnabled(profile.getCommuterEnabled())
                .commuterDestinationA(profile.getCommuterDestinationA())
                .commuterDestinationB(profile.getCommuterDestinationB())
                .commuteFairnessWeight(profile.getCommuteFairnessWeight())
                .build();
    }

    private String join(List<String> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        return values.stream()
                .filter(value -> value != null && !value.isBlank())
                .map(String::trim)
                .reduce((left, right) -> left + "," + right)
                .orElse(null);
    }

    private List<String> split(String csv) {
        if (csv == null || csv.isBlank()) {
            return List.of();
        }
        return Arrays.stream(csv.split(","))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .toList();
    }
}
