package com.habitathero.entity;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "resale_transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResaleTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "block_id")
    private Long blockId;

    private String town;

    @Column(name = "resale_price")
    private Double resalePrice;

    @Column(name = "floor_area_sqm")
    private Double floorAreaSqm;

    @Column(name = "lease_commencement_date")
    private LocalDate leaseCommencementDate;

    @Column(name = "transaction_month")
    private String transactionMonth;
}
