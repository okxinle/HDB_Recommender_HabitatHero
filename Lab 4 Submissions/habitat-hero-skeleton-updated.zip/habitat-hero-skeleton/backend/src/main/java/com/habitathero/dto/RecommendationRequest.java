package com.habitathero.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class RecommendationRequest {

    @Valid
    @NotNull
    private ProfileRequest profile;

    /**
     * Optional client-side hint for limiting results.
     */
    private Integer limit;
}
