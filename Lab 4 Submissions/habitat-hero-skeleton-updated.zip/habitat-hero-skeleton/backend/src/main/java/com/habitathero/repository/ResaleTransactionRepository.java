package com.habitathero.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.habitathero.entity.ResaleTransaction;

public interface ResaleTransactionRepository extends JpaRepository<ResaleTransaction, Long> {

    List<ResaleTransaction> findByTownIgnoreCase(String town);

    @Query("""
            select avg(r.resalePrice / nullif(r.floorAreaSqm * 10.7639, 0))
            from ResaleTransaction r
            where upper(r.town) = upper(?1)
            """)
    Double findAveragePsfByTown(String town);
}
