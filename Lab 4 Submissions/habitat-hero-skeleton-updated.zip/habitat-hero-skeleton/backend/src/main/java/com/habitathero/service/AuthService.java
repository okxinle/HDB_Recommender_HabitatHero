package com.habitathero.service;

import java.time.LocalDateTime;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.habitathero.dto.AuthRequest;
import com.habitathero.dto.AuthResponse;
import com.habitathero.entity.UserAccount;
import com.habitathero.repository.UserAccountRepository;

@Service
public class AuthService {

    private final UserAccountRepository userAccountRepository;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokenService;

    public AuthService(
            UserAccountRepository userAccountRepository,
            PasswordEncoder passwordEncoder,
            TokenService tokenService) {
        this.userAccountRepository = userAccountRepository;
        this.passwordEncoder = passwordEncoder;
        this.tokenService = tokenService;
    }

    public AuthResponse register(AuthRequest request) {
        if (userAccountRepository.findByEmailIgnoreCase(request.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Registration Invalid. Account already exists");
        }

        UserAccount account = UserAccount.builder()
                .name(request.getName() == null || request.getName().isBlank() ? "HabitatHero User" : request.getName().trim())
                .email(request.getEmail().trim().toLowerCase())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .role("USER")
                .active(true)
                .build();

        UserAccount saved = userAccountRepository.save(account);
        return buildResponse(saved, "Account created successfully. Please log in.");
    }

    public AuthResponse login(AuthRequest request) {
        UserAccount account = userAccountRepository.findByEmailIgnoreCase(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));

        if (account.getLockUntil() != null && LocalDateTime.now().isBefore(account.getLockUntil())) {
            throw new IllegalStateException("Too many attempts. Please try again later.");
        }

        if (!passwordEncoder.matches(request.getPassword(), account.getPasswordHash())) {
            int newAttempts = account.getFailedLoginAttempts() == null ? 1 : account.getFailedLoginAttempts() + 1;
            account.setFailedLoginAttempts(newAttempts);

            if (newAttempts >= 5) {
                account.setLockUntil(LocalDateTime.now().plusMinutes(15));
                userAccountRepository.save(account);
                throw new IllegalStateException("Too many attempts. Please try again later.");
            }

            userAccountRepository.save(account);
            throw new IllegalArgumentException("Invalid email or password");
        }

        account.setFailedLoginAttempts(0);
        account.setLockUntil(null);
        UserAccount saved = userAccountRepository.save(account);
        return buildResponse(saved, "Login successful");
    }

    private AuthResponse buildResponse(UserAccount account, String message) {
        String token = tokenService.generate(account);
        return AuthResponse.builder()
                .token(token)
                .userId(account.getId())
                .name(account.getName())
                .email(account.getEmail())
                .role(account.getRole())
                .message(message)
                .build();
    }
}
