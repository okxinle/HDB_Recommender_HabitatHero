package com.habitathero.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class AuthResponse {
    String token;
    Long userId;
    String name;
    String email;
    String role;
    String message;
}
