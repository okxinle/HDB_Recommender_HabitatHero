package com.habitathero.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "global_algorithm_configs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GlobalAlgorithmConfig {

    @Id
    @Column(name = "config_key", length = 100)
    private String key;

    @Column(name = "config_value", nullable = false)
    private Double value;

    private String description;
}
