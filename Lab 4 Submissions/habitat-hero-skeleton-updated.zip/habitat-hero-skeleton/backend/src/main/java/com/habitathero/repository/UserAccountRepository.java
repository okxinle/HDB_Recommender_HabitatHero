package com.habitathero.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.habitathero.entity.UserAccount;

public interface UserAccountRepository extends JpaRepository<UserAccount, Long> {
    Optional<UserAccount> findByEmailIgnoreCase(String email);
}
