package com.habitathero.service;

import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Service;

import com.habitathero.entity.HDBBlock;

/**
 * Deterministic placeholder geospatial service.
 *
 * It mirrors the SRS feature set:
 * - solar orientation
 * - acoustic comfort
 * - convenience amenity proximity
 * - future development risk
 */
@Service
public class GeospatialService {

    public double computeSolarScore(HDBBlock block) {
        if (block.getWestExposurePct() != null) {
            return clamp01(1.0 - (block.getWestExposurePct() / 100.0));
        }
        if (Boolean.TRUE.equals(block.getWestSunStatus())) {
            return 0.2;
        }
        return 0.8;
    }

    public double computeAcousticScore(HDBBlock block) {
        if (block.getNoiseLevelDb() == null) {
            return "LOW".equalsIgnoreCase(block.getNoiseRiskLevel()) ? 0.8 : 0.5;
        }

        if (block.getNoiseLevelDb() <= 55.0) {
            return 1.0;
        }
        if (block.getNoiseLevelDb() >= 85.0) {
            return 0.0;
        }
        return clamp01(1.0 - ((block.getNoiseLevelDb() - 55.0) / 30.0));
    }

    public double computeConvenienceScore(HDBBlock block, List<String> selectedAmenities) {
        if (selectedAmenities == null || selectedAmenities.isEmpty()) {
            return 1.0;
        }

        long matches = selectedAmenities.stream()
                .map(value -> value == null ? "" : value.trim().toUpperCase(Locale.ROOT))
                .filter(name -> amenityMatched(block, name))
                .count();

        return clamp01((double) matches / selectedAmenities.size());
    }

    public boolean isFutureRisk(HDBBlock block) {
        if (block.getFutureRiskFlag() != null) {
            return block.getFutureRiskFlag();
        }
        return block.getFutureDevelopmentCount() != null && block.getFutureDevelopmentCount() > 0;
    }

    private boolean amenityMatched(HDBBlock block, String amenityName) {
        return switch (amenityName) {
            case "SCHOOL", "SCHOOLS" -> valueOrZero(block.getNearbySchoolCount()) > 0;
            case "HAWKER", "HAWKER_CENTRE", "HAWKER CENTRE" -> valueOrZero(block.getNearbyHawkerCount()) > 0;
            case "SUPERMARKET", "SUPERMARKETS" -> valueOrZero(block.getNearbySupermarketCount()) > 0;
            case "PARK", "PARKS" -> valueOrZero(block.getNearbyParkCount()) > 0;
            case "HOSPITAL", "HOSPITALS" -> valueOrZero(block.getNearbyHospitalCount()) > 0;
            case "PLAYGROUND", "PLAYGROUNDS" -> valueOrZero(block.getNearbyPlaygroundCount()) > 0;
            case "PARENTS", "PARENTS_ADDRESS", "PARENTS' ADDRESS" ->
                    block.getDistanceToParentsKm() != null && block.getDistanceToParentsKm() <= 4.0;
            default -> false;
        };
    }

    private int valueOrZero(Integer value) {
        return value == null ? 0 : value;
    }

    private double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
