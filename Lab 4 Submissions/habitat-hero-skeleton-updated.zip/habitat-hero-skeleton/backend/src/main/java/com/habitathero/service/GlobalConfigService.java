package com.habitathero.service;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.habitathero.entity.GlobalAlgorithmConfig;
import com.habitathero.repository.GlobalAlgorithmConfigRepository;

@Service
public class GlobalConfigService {

    private final GlobalAlgorithmConfigRepository repository;

    public GlobalConfigService(GlobalAlgorithmConfigRepository repository) {
        this.repository = repository;
    }

    public Map<String, Double> getEffectiveWeights() {
        Map<String, Double> weights = new LinkedHashMap<>();
        weights.put("solar_default_weight", 0.34);
        weights.put("acoustic_default_weight", 0.33);
        weights.put("convenience_default_weight", 0.33);
        weights.put("strict_solar_threshold", 0.50);
        weights.put("strict_acoustic_threshold", 0.50);
        weights.put("strict_convenience_threshold", 0.50);

        repository.findAll().forEach(item -> weights.put(item.getKey(), item.getValue()));
        return weights;
    }

    @Transactional
    public Map<String, Double> update(Map<String, Double> updates) {
        updates.forEach((key, value) -> repository.save(GlobalAlgorithmConfig.builder()
                .key(key)
                .value(value)
                .description("Runtime-tunable algorithm setting")
                .build()));
        return getEffectiveWeights();
    }
}
