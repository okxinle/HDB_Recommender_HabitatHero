package com.habitathero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class HabitatHeroApplication {

    public static void main(String[] args) {
        SpringApplication.run(HabitatHeroApplication.class, args);
    }
}
