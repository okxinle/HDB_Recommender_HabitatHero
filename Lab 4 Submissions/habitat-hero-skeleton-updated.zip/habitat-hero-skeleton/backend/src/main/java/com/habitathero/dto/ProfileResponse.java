package com.habitathero.dto;

import java.util.List;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ProfileResponse {
    Long userId;
    Double budgetMin;
    Double budgetMax;
    List<String> preferredRegions;
    List<String> preferredTowns;
    String preferredFlatType;
    Integer minLeaseYears;
    String solarMode;
    Double solarWeight;
    String acousticMode;
    Double acousticWeight;
    String convenienceMode;
    Double convenienceWeight;
    List<String> selectedAmenities;
    String parentsPostalCode;
    Boolean commuterEnabled;
    String commuterDestinationA;
    String commuterDestinationB;
    Double commuteFairnessWeight;
}
