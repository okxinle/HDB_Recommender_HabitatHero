package com.habitathero.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.habitathero.dto.RecommendationRequest;
import com.habitathero.repository.HDBBlockRepository;
import com.habitathero.service.RecommendationEngine;

@RestController
@RequestMapping("/api/hdb")
public class RecommendationController {

    private final RecommendationEngine recommendationEngine;
    private final HDBBlockRepository hdbBlockRepository;

    public RecommendationController(RecommendationEngine recommendationEngine, HDBBlockRepository hdbBlockRepository) {
        this.recommendationEngine = recommendationEngine;
        this.hdbBlockRepository = hdbBlockRepository;
    }

    @PostMapping("/recommend")
    public ResponseEntity<?> recommend(@RequestBody RecommendationRequest request) {
        return ResponseEntity.ok(recommendationEngine.generateRecommendations(request));
    }

    @GetMapping("/{postalCode}/details")
    public ResponseEntity<?> getBlockDetails(@PathVariable String postalCode) {
        return hdbBlockRepository.findByPostalCode(postalCode)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
