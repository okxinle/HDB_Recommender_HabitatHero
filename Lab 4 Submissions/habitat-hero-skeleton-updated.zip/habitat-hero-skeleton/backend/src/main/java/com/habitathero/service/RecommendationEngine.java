package com.habitathero.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.habitathero.dto.BlockMatchDto;
import com.habitathero.dto.ProfileRequest;
import com.habitathero.dto.RecommendationRequest;
import com.habitathero.dto.RecommendationResponse;
import com.habitathero.entity.HDBBlock;
import com.habitathero.repository.HDBBlockRepository;
import com.habitathero.repository.ResaleTransactionRepository;

/**
 * SRS-driven recommendation skeleton.
 *
 * Implements:
 * - hard filtering
 * - optional commute scoring
 * - solar/acoustic/convenience soft scoring
 * - strict vs weighted preference handling
 * - global match index ranking
 */
@Service
public class RecommendationEngine {

    private static final String MODE_IGNORE = "IGNORE";
    private static final String MODE_STRICT = "STRICT";
    private static final String MODE_WEIGHTED = "WEIGHTED";

    private final HDBBlockRepository hdbBlockRepository;
    private final ResaleTransactionRepository resaleTransactionRepository;
    private final GeospatialService geospatialService;
    private final GlobalConfigService globalConfigService;

    public RecommendationEngine(
            HDBBlockRepository hdbBlockRepository,
            ResaleTransactionRepository resaleTransactionRepository,
            GeospatialService geospatialService,
            GlobalConfigService globalConfigService) {
        this.hdbBlockRepository = hdbBlockRepository;
        this.resaleTransactionRepository = resaleTransactionRepository;
        this.geospatialService = geospatialService;
        this.globalConfigService = globalConfigService;
    }

    public RecommendationResponse generateRecommendations(RecommendationRequest request) {
        if (request == null || request.getProfile() == null) {
            throw new IllegalArgumentException("Request body is missing user profile data.");
        }

        ProfileRequest profile = request.getProfile();
        validateProfile(profile);

        List<HDBBlock> candidates = hdbBlockRepository.findAll().stream()
                .filter(block -> matchesStructuralConstraints(block, profile))
                .toList();

        if (candidates.isEmpty()) {
            return RecommendationResponse.builder()
                    .status("no_matches")
                    .warning("No Matches Found. Please broaden your search criteria.")
                    .candidateCount(0)
                    .results(List.of())
                    .build();
        }

        Map<String, Double> config = globalConfigService.getEffectiveWeights();
        List<BlockMatchDto> ranked = new ArrayList<>();

        for (HDBBlock block : candidates) {
            double solarScore = geospatialService.computeSolarScore(block);
            double acousticScore = geospatialService.computeAcousticScore(block);
            double convenienceScore = geospatialService.computeConvenienceScore(block, safeList(profile.getSelectedAmenities()));

            if (!passesStrictConstraints(block, profile, solarScore, acousticScore, convenienceScore, config)) {
                continue;
            }

            double normalizedLivability = calculateNormalizedLivability(profile, solarScore, acousticScore, convenienceScore, config);
            CommuteMetrics commuteMetrics = calculateCommuteMetrics(block, profile);

            double globalMatchIndex = Boolean.TRUE.equals(profile.getCommuterEnabled())
                    ? ((normalizedLivability + commuteMetrics.commuteScore) / 2.0) * 100.0
                    : normalizedLivability * 100.0;

            ranked.add(toDto(block, clamp(globalMatchIndex, 0.0, 100.0), commuteMetrics));
        }

        ranked.sort(Comparator
                .comparing(BlockMatchDto::getGlobalMatchIndex, Comparator.nullsLast(Comparator.reverseOrder()))
                .thenComparing(BlockMatchDto::getEstimatedPrice, Comparator.nullsLast(Double::compareTo)));

        int limit = request.getLimit() == null ? 20 : Math.max(1, request.getLimit());
        List<BlockMatchDto> finalResults = ranked.stream().limit(limit).toList();

        return RecommendationResponse.builder()
                .status(finalResults.isEmpty() ? "no_matches" : "success")
                .warning(finalResults.isEmpty() ? "No blocks remained after strict preference filtering." : null)
                .candidateCount(finalResults.size())
                .results(finalResults)
                .build();
    }

    private void validateProfile(ProfileRequest profile) {
        if (profile.getBudgetMax() != null && profile.getBudgetMax() <= 0) {
            throw new IllegalArgumentException("Budget max must be positive.");
        }
        if (profile.getMinLeaseYears() != null && profile.getMinLeaseYears() < 0) {
            throw new IllegalArgumentException("Minimum lease years cannot be negative.");
        }

        if (Boolean.TRUE.equals(profile.getCommuterEnabled())) {
            if (!isValidPostal(profile.getCommuterDestinationA()) || !isValidPostal(profile.getCommuterDestinationB())) {
                throw new IllegalArgumentException("Multi-commuter mode requires exactly two 6-digit postal codes.");
            }
        }

        if (MODE_WEIGHTED.equals(normalizeMode(profile.getConvenienceMode()))
                && (profile.getConvenienceWeight() == null || profile.getConvenienceWeight() < 0 || profile.getConvenienceWeight() > 1)) {
            throw new IllegalArgumentException("Convenience weight must be between 0 and 1.");
        }
    }

    private boolean matchesStructuralConstraints(HDBBlock block, ProfileRequest profile) {
        if (profile.getBudgetMax() != null && block.getEstimatedPrice() != null && block.getEstimatedPrice() > profile.getBudgetMax()) {
            return false;
        }
        if (profile.getBudgetMin() != null && block.getEstimatedPrice() != null && block.getEstimatedPrice() < profile.getBudgetMin()) {
            return false;
        }
        if (profile.getMinLeaseYears() != null && block.getRemainingLeaseYears() != null
                && block.getRemainingLeaseYears() < profile.getMinLeaseYears()) {
            return false;
        }
        if (profile.getPreferredFlatType() != null && !profile.getPreferredFlatType().isBlank()
                && !profile.getPreferredFlatType().equalsIgnoreCase(block.getFlatType())) {
            return false;
        }
        if (profile.getPreferredTowns() != null && !profile.getPreferredTowns().isEmpty()) {
            boolean townMatch = profile.getPreferredTowns().stream()
                    .filter(Objects::nonNull)
                    .anyMatch(town -> town.trim().equalsIgnoreCase(block.getTown()));
            if (!townMatch) {
                return false;
            }
        }
        if (profile.getPreferredRegions() != null && !profile.getPreferredRegions().isEmpty()) {
            boolean regionMatch = profile.getPreferredRegions().stream()
                    .filter(Objects::nonNull)
                    .anyMatch(region -> region.trim().equalsIgnoreCase(block.getRegion()));
            if (!regionMatch) {
                return false;
            }
        }
        return true;
    }

    private boolean passesStrictConstraints(
            HDBBlock block,
            ProfileRequest profile,
            double solarScore,
            double acousticScore,
            double convenienceScore,
            Map<String, Double> config) {

        if (MODE_STRICT.equals(normalizeMode(profile.getSolarMode())) && solarScore < config.getOrDefault("strict_solar_threshold", 0.50)) {
            return false;
        }
        if (MODE_STRICT.equals(normalizeMode(profile.getAcousticMode())) && acousticScore < config.getOrDefault("strict_acoustic_threshold", 0.50)) {
            return false;
        }
        if (MODE_STRICT.equals(normalizeMode(profile.getConvenienceMode()))
                && !safeList(profile.getSelectedAmenities()).isEmpty()
                && convenienceScore < config.getOrDefault("strict_convenience_threshold", 0.50)) {
            return false;
        }
        if (Boolean.TRUE.equals(block.getFutureRiskFlag()) && safeList(profile.getSelectedAmenities()).contains("RESERVE_SITE_AVOIDANCE")) {
            return false;
        }
        return true;
    }

    private double calculateNormalizedLivability(
            ProfileRequest profile,
            double solarScore,
            double acousticScore,
            double convenienceScore,
            Map<String, Double> config) {

        double totalWeight = 0.0;
        double weightedScore = 0.0;

        if (MODE_WEIGHTED.equals(normalizeMode(profile.getSolarMode()))) {
            double weight = defaultedWeight(profile.getSolarWeight(), config.getOrDefault("solar_default_weight", 0.34));
            totalWeight += weight;
            weightedScore += solarScore * weight;
        }

        if (MODE_WEIGHTED.equals(normalizeMode(profile.getAcousticMode()))) {
            double weight = defaultedWeight(profile.getAcousticWeight(), config.getOrDefault("acoustic_default_weight", 0.33));
            totalWeight += weight;
            weightedScore += acousticScore * weight;
        }

        if (MODE_WEIGHTED.equals(normalizeMode(profile.getConvenienceMode()))) {
            double weight = defaultedWeight(profile.getConvenienceWeight(), config.getOrDefault("convenience_default_weight", 0.33));
            totalWeight += weight;
            weightedScore += convenienceScore * weight;
        }

        if (totalWeight == 0.0) {
            return 1.0;
        }
        return clamp(weightedScore / totalWeight, 0.0, 1.0);
    }

    private CommuteMetrics calculateCommuteMetrics(HDBBlock block, ProfileRequest profile) {
        if (!Boolean.TRUE.equals(profile.getCommuterEnabled())) {
            return new CommuteMetrics(null, null, 1.0);
        }

        double travelA = estimateTravelMinutes(block, profile.getCommuterDestinationA());
        double travelB = estimateTravelMinutes(block, profile.getCommuterDestinationB());
        double total = travelA + travelB;
        double fairness = 1.0 / (1.0 + Math.abs(travelA - travelB));
        double efficiency = 1.0 / (1.0 + (total / 60.0));
        double commuteScore = clamp((0.6 * fairness) + (0.4 * efficiency), 0.0, 1.0);

        return new CommuteMetrics(round2(fairness), round2(total), round2(commuteScore));
    }

    private double estimateTravelMinutes(HDBBlock block, String destinationPostal) {
        int destinationSeed = Integer.parseInt(destinationPostal.substring(0, 3));
        int blockSeed = 0;
        if (block.getPostalCode() != null && block.getPostalCode().length() >= 3) {
            blockSeed = Integer.parseInt(block.getPostalCode().substring(0, 3));
        }
        double proximityPenalty = Math.abs(destinationSeed - blockSeed) / 12.0;
        double railPenalty = block.getDistanceToTransportMeters() == null ? 10.0 : Math.min(20.0, block.getDistanceToTransportMeters() / 100.0);
        return round2(15.0 + proximityPenalty + railPenalty);
    }

    private BlockMatchDto toDto(HDBBlock block, double globalMatchIndex, CommuteMetrics commuteMetrics) {
        Double benchmarkPsf = block.getTown() == null ? null : resaleTransactionRepository.findAveragePsfByTown(block.getTown());

        return BlockMatchDto.builder()
                .blockId(block.getId())
                .postalCode(block.getPostalCode())
                .blockLabel(block.getBlockLabel())
                .town(block.getTown())
                .region(block.getRegion())
                .flatType(block.getFlatType())
                .estimatedPrice(block.getEstimatedPrice())
                .remainingLeaseYears(block.getRemainingLeaseYears())
                .floorAreaSqm(block.getFloorAreaSqm())
                .globalMatchIndex(round2(globalMatchIndex))
                .commuteScore(commuteMetrics.commuteScore)
                .fairnessIndex(commuteMetrics.fairnessIndex)
                .totalCommuteBurden(commuteMetrics.totalCommuteBurden)
                .westSunStatus(block.getWestSunStatus())
                .westExposurePct(block.getWestExposurePct())
                .noiseRiskLevel(block.getNoiseRiskLevel())
                .noiseLevelDb(block.getNoiseLevelDb())
                .futureRiskFlag(geospatialService.isFutureRisk(block))
                .futureDevelopmentCount(block.getFutureDevelopmentCount())
                .latitude(block.getLatitude())
                .longitude(block.getLongitude())
                .build();
    }

    private List<String> safeList(List<String> values) {
        return values == null ? List.of() : values.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .map(value -> value.toUpperCase(Locale.ROOT))
                .toList();
    }

    private String normalizeMode(String value) {
        return value == null ? MODE_IGNORE : value.trim().toUpperCase(Locale.ROOT);
    }

    private boolean isValidPostal(String value) {
        return value != null && value.matches("\\d{6}");
    }

    private double defaultedWeight(Double value, double fallback) {
        return value == null ? fallback : clamp(value, 0.0, 1.0);
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private record CommuteMetrics(Double fairnessIndex, Double totalCommuteBurden, Double commuteScore) {}
}
