package com.habitathero.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "hdb_blocks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HDBBlock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "block_label")
    private String blockLabel;

    @Column(name = "postal_code", unique = true)
    private String postalCode;

    private String town;
    private String region;

    @Column(name = "flat_type")
    private String flatType;

    @Column(name = "estimated_price")
    private Double estimatedPrice;

    @Column(name = "remaining_lease_years")
    private Integer remainingLeaseYears;

    @Column(name = "floor_area_sqm")
    private Double floorAreaSqm;

    private Double latitude;
    private Double longitude;

    @Column(name = "west_sun_status")
    private Boolean westSunStatus;

    @Column(name = "west_exposure_pct")
    private Double westExposurePct;

    @Column(name = "noise_risk_level")
    private String noiseRiskLevel;

    @Column(name = "noise_level_db")
    private Double noiseLevelDb;

    @Column(name = "distance_to_transport_meters")
    private Double distanceToTransportMeters;

    @Column(name = "future_risk_flag")
    private Boolean futureRiskFlag;

    @Column(name = "future_development_count")
    private Integer futureDevelopmentCount;

    @Column(name = "distance_to_parents_km")
    private Double distanceToParentsKm;

    @Column(name = "nearby_school_count")
    private Integer nearbySchoolCount;

    @Column(name = "nearby_hawker_count")
    private Integer nearbyHawkerCount;

    @Column(name = "nearby_supermarket_count")
    private Integer nearbySupermarketCount;

    @Column(name = "nearby_park_count")
    private Integer nearbyParkCount;

    @Column(name = "nearby_hospital_count")
    private Integer nearbyHospitalCount;

    @Column(name = "nearby_playground_count")
    private Integer nearbyPlaygroundCount;

    @Transient
    private Double globalMatchIndex;

    @Transient
    private Double commuteScore;

    @Transient
    private Double fairnessIndex;

    @Transient
    private Double totalCommuteBurden;
}
