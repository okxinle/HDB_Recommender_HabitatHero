package com.habitathero.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.habitathero.entity.GlobalAlgorithmConfig;

public interface GlobalAlgorithmConfigRepository extends JpaRepository<GlobalAlgorithmConfig, String> {
}
