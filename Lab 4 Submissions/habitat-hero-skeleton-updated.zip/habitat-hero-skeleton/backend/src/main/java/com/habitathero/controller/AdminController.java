package com.habitathero.controller;

import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.habitathero.service.AuditLogService;
import com.habitathero.service.DataSyncService;
import com.habitathero.service.GlobalConfigService;
import com.habitathero.service.TokenService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final DataSyncService dataSyncService;
    private final GlobalConfigService globalConfigService;
    private final AuditLogService auditLogService;

    public AdminController(
            DataSyncService dataSyncService,
            GlobalConfigService globalConfigService,
            AuditLogService auditLogService) {
        this.dataSyncService = dataSyncService;
        this.globalConfigService = globalConfigService;
        this.auditLogService = auditLogService;
    }

    @PostMapping("/trigger-sync")
    public ResponseEntity<?> triggerSync(Authentication authentication, HttpServletRequest request) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(dataSyncService.triggerResaleSync(principal.email(), request.getRemoteAddr()));
    }

    @PostMapping("/init-hdb-building")
    public ResponseEntity<?> initHdbBuilding(Authentication authentication, HttpServletRequest request) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(dataSyncService.initHdbBuilding(principal.email(), request.getRemoteAddr()));
    }

    @PostMapping("/backfill-coordinates")
    public ResponseEntity<?> backfillCoordinates(Authentication authentication, HttpServletRequest request) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(dataSyncService.backfillCoordinates(principal.email(), request.getRemoteAddr()));
    }

    @PostMapping("/init-land-use")
    public ResponseEntity<?> initLandUse(Authentication authentication, HttpServletRequest request) {
        TokenService.TokenPrincipal principal = (TokenService.TokenPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(dataSyncService.initLandUse(principal.email(), request.getRemoteAddr()));
    }

    @PatchMapping("/weights")
    public ResponseEntity<?> updateWeights(@RequestBody Map<String, Double> updates) {
        return ResponseEntity.ok(globalConfigService.update(updates));
    }

    @GetMapping("/logs")
    public ResponseEntity<List<?>> logs() {
        return ResponseEntity.ok(auditLogService.latest());
    }
}
