package com.habitathero.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class BlockMatchDto {
    Long blockId;
    String postalCode;
    String blockLabel;
    String town;
    String region;
    String flatType;
    Double estimatedPrice;
    Integer remainingLeaseYears;
    Double floorAreaSqm;
    Double globalMatchIndex;
    Double commuteScore;
    Double fairnessIndex;
    Double totalCommuteBurden;
    Boolean westSunStatus;
    Double westExposurePct;
    String noiseRiskLevel;
    Double noiseLevelDb;
    Boolean futureRiskFlag;
    Integer futureDevelopmentCount;
    Double latitude;
    Double longitude;
}
