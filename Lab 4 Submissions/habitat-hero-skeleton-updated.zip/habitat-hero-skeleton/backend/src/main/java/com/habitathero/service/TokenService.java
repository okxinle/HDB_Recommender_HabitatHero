package com.habitathero.service;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.habitathero.entity.UserAccount;

/**
 * Lightweight placeholder token service.
 *
 * This is not production-grade JWT signing; it gives the skeleton a stateless
 * Bearer-token shape that matches the SRS communication and auth model.
 */
@Service
public class TokenService {

    @Value("${habitathero.token.expiry-hours:24}")
    private long expiryHours;

    @Value("${habitathero.token.secret:dev-secret-change-me}")
    private String secret;

    public String generate(UserAccount account) {
        long expiryEpoch = Instant.now().plus(expiryHours, ChronoUnit.HOURS).getEpochSecond();
        String payload = account.getId() + "|" + account.getEmail() + "|" + account.getRole() + "|" + expiryEpoch + "|" + secret;
        return Base64.getUrlEncoder().encodeToString(payload.getBytes(StandardCharsets.UTF_8));
    }

    public Optional<TokenPrincipal> parse(String token) {
        try {
            String decoded = new String(Base64.getUrlDecoder().decode(token), StandardCharsets.UTF_8);
            String[] parts = decoded.split("\\|");
            if (parts.length != 5 || !secret.equals(parts[4])) {
                return Optional.empty();
            }

            long expiryEpoch = Long.parseLong(parts[3]);
            if (Instant.now().getEpochSecond() > expiryEpoch) {
                return Optional.empty();
            }

            return Optional.of(new TokenPrincipal(
                    Long.parseLong(parts[0]),
                    parts[1],
                    parts[2]));
        } catch (Exception ignored) {
            return Optional.empty();
        }
    }

    public record TokenPrincipal(Long userId, String email, String role) {}
}
