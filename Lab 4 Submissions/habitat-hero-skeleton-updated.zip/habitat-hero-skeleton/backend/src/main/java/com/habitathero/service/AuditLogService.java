package com.habitathero.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.habitathero.entity.AuditLog;
import com.habitathero.repository.AuditLogRepository;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public AuditLog log(String adminEmail, String actionName, String endpointUrl, String ipAddress, String details, String status) {
        return auditLogRepository.save(AuditLog.builder()
                .adminEmail(adminEmail)
                .actionName(actionName)
                .endpointUrl(endpointUrl)
                .ipAddress(ipAddress)
                .details(details)
                .status(status)
                .build());
    }

    public List<AuditLog> latest() {
        return auditLogRepository.findTop50ByOrderByCreatedAtDesc();
    }
}
