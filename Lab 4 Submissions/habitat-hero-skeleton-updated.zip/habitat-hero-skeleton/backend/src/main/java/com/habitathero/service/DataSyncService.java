package com.habitathero.service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Headless admin-oriented sync service aligned to the SRS.
 *
 * The methods return structured status maps so the admin API can remain stable
 * even while real integrations are wired in later.
 */
@Service
public class DataSyncService {

    private final AuditLogService auditLogService;

    @Value("${habitathero.datagov.api-key:}")
    private String dataGovApiKey;

    public DataSyncService(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    @Scheduled(cron = "${habitathero.sync.resale-cron:0 0 2 * * *}")
    public void scheduledResaleSync() {
        if (dataGovApiKey == null || dataGovApiKey.isBlank()) {
            return;
        }
        auditLogService.log("system", "scheduled-resale-sync", "/scheduler/resale-sync", "127.0.0.1",
                "Scheduled sync executed by skeleton service", "SUCCESS");
    }

    public Map<String, Object> triggerResaleSync(String adminEmail, String ipAddress) {
        Map<String, Object> response = base("trigger-sync");
        response.put("message", dataGovApiKey == null || dataGovApiKey.isBlank()
                ? "Sync stub executed. Configure DATAGOV_API_KEY for live integration."
                : "Sync stub executed. Replace with real Data.gov.sg ingestion in DataSyncService.");
        auditLogService.log(adminEmail, "trigger-sync", "/api/admin/trigger-sync", ipAddress, response.toString(), "SUCCESS");
        return response;
    }

    public Map<String, Object> initHdbBuilding(String adminEmail, String ipAddress) {
        Map<String, Object> response = base("init-hdb-building");
        response.put("message", "HDB building dataset initialization stub executed.");
        auditLogService.log(adminEmail, "init-hdb-building", "/api/admin/init-hdb-building", ipAddress, response.toString(), "SUCCESS");
        return response;
    }

    public Map<String, Object> backfillCoordinates(String adminEmail, String ipAddress) {
        Map<String, Object> response = base("backfill-coordinates");
        response.put("candidatesScanned", 0);
        response.put("updatedBlocks", 0);
        response.put("unresolvedBlocks", 0);
        auditLogService.log(adminEmail, "backfill-coordinates", "/api/admin/backfill-coordinates", ipAddress, response.toString(), "SUCCESS");
        return response;
    }

    public Map<String, Object> initLandUse(String adminEmail, String ipAddress) {
        Map<String, Object> response = base("init-land-use");
        response.put("message", "Land-use initialization stub executed.");
        response.put("tableReady", true);
        response.put("downloadedGeoJson", false);
        response.put("importedToDb", false);
        auditLogService.log(adminEmail, "init-land-use", "/api/admin/init-land-use", ipAddress, response.toString(), "SUCCESS");
        return response;
    }

    private Map<String, Object> base(String action) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("action", action);
        payload.put("timestamp", LocalDateTime.now());
        payload.put("status", "success");
        return payload;
    }
}
