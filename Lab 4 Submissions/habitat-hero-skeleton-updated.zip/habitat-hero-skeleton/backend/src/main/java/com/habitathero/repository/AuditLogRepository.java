package com.habitathero.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.habitathero.entity.AuditLog;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    List<AuditLog> findTop50ByOrderByCreatedAtDesc();
}
