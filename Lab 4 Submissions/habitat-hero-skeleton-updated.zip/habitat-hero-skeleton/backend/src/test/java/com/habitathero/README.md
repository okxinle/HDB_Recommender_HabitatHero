# Backend Testing Notes

Recommended tests based on the SRS:
- RecommendationEngine hard-filter and scoring unit tests
- AuthService login/lockout tests
- ProfileController integration tests
- AdminController authorization tests
